package com.randomactivity.launcher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Has no UI: on open it picks a random installed app, then a random exported
 * activity of that app, launches it, and closes itself.
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!launchRandomActivity()) {
            Toast.makeText(this, R.string.nothing_launched, Toast.LENGTH_LONG).show();
        }
        finish();
    }

    private boolean launchRandomActivity() {
        PackageManager pm = getPackageManager();
        List<PackageInfo> packages = new ArrayList<>(pm.getInstalledPackages(0));
        Collections.shuffle(packages);

        for (PackageInfo p : packages) {
            if (p.packageName.equals(getPackageName())) continue;

            PackageInfo full;
            try {
                full = pm.getPackageInfo(p.packageName, PackageManager.GET_ACTIVITIES);
            } catch (Exception e) {
                continue;
            }
            if (full.applicationInfo == null || !full.applicationInfo.enabled) continue;
            if (full.activities == null) continue;

            List<ActivityInfo> candidates = new ArrayList<>();
            for (ActivityInfo a : full.activities) {
                if (a.exported && a.enabled && a.permission == null) {
                    candidates.add(a);
                }
            }
            Collections.shuffle(candidates);

            for (ActivityInfo a : candidates) {
                try {
                    Intent intent = new Intent();
                    intent.setComponent(new ComponentName(a.packageName, a.name));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    CharSequence label = full.applicationInfo.loadLabel(pm);
                    Toast.makeText(this,
                            label + "\n" + a.name.substring(a.name.lastIndexOf('.') + 1),
                            Toast.LENGTH_SHORT).show();
                    return true;
                } catch (Exception e) {
                    // Not launchable (security, missing, etc.): try another one.
                }
            }
        }
        return false;
    }
}

# Random Launcher

Open the app and it instantly launches a random exported activity of a random installed app, then closes itself.

## Build
- Locally: `gradle assembleRelease` (Gradle 8.9+, JDK 17, Android SDK 34). Run `gradle wrapper` once if you want a wrapper.
- GitHub: push a tag like `v1.0.0` (or run the workflow manually) and the APK is attached to a new release.

## Optional signing secrets
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Without them the release APK is signed with the debug key.

## Notes
- Uses `QUERY_ALL_PACKAGES` (fine for sideloading, not Play Store).
- Only exported activities with no permission requirement are tried; some may crash or show odd screens without the extras they expect.
